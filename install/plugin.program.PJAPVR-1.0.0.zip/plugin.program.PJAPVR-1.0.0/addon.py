import xbmcaddon
import xbmcgui
import urllib, os,re,urllib2
import xbmc
import shutil
import xbmcplugin

profile = xbmc.translatePath('special://profile//')
_addonpvr = xbmcaddon.Addon(id = 'pvr.iptvsimple')
profilePath2 = xbmc.translatePath(_addonpvr.getAddonInfo('profile'))
def DownloaderClass(url,dest):
    dp = xbmcgui.DialogProgress()
    dp.create("Downloading TV Guide","Downloading File")
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
 
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        print percent
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled(): 
        print "DOWNLOAD CANCELLED" 
        del window
	dp.close()
 
dialog = xbmcgui.Dialog()
inp = dialog.input('Please enter your username', type=xbmcgui.INPUT_ALPHANUM)
url2 = 'http://pjalpha.co.nf/Adult/' + inp + '/settings.xml'
# url2 = 'http://www.pjalpha.co.nf/pvr/settings.xml'




dest2 = profilePath2 + 'settings.xml'
try:
	DownloaderClass(url2, dest2)
except:
	xbmcgui.Dialog().ok("Invalid Username", "Your username is incorrect")





xbmcgui.Dialog().ok("PJA TV Install", "Install Complete, Please press the home button once, then select kodi, press menu and force stop and then restart Kodi")
