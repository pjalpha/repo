import xbmc,xbmcaddon,xbmcgui,xbmcplugin,urllib,urllib2,os,re,sys,urlresolver,liveresolver,urlparse,hashlib
import datetime
import time

args = urlparse.parse_qs(sys.argv[2][1:])
mode = args.get('mode', None)
user=xbmcplugin.getSetting(int(sys.argv[1]), 'user')
pword=xbmcplugin.getSetting(int(sys.argv[1]), 'pass')
lupdated=xbmcplugin.getSetting(int(sys.argv[1]), 'lastupdated')
date = time.strftime("%d%m%y")


def pProtect(pw):
	ret = hashlib.sha224(pw).hexdigest()
	return ret
def GetUrl(Durl):
		Durl=Durl.replace(' ','%20')
		request = urllib2.Request(Durl)
		request.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
		handle = urllib2.urlopen(request)
		content = handle.read()  
		handle.close()
		return content
		
def GetHome(url):
	Data=GetUrl(url)
	result =re.compile('<channel>(.+?)</channel>',re.DOTALL).findall(Data)
	for item in result:
		channels=re.compile('<url>(.+?)</url>',re.DOTALL).findall(item)
		for url in channels:
			val=url
		return url
			
def GetData(url):
	Data=GetUrl(url)
	result=re.compile('<channel>(.+?)</channel>',re.DOTALL).findall(Data)
	for item in result:
		channels=re.compile('<name>(.+?)</name>.+?url>(.+?)</url>.+?image>(.+?)</image>.+?type>(.+?)</type>.+?img>(.+?)</img>',re.DOTALL).findall(item)
		for name,url,image,type,img in channels:
			
			if type == '3':
				addmenu(name,url,type,image)
			else:
				if type == '4':
					addmenu(name,url,type,image)
				else:
					if type =='5':
						addmenu(name,url,type,image)
					else:
						addChannel(name,url,type,image,type,img)
def GetDataTV(url):
	Data=GetUrl(url)
	result=re.compile('<channel>(.+?)</channel>',re.DOTALL).findall(Data)
	for item in result:
		channels=re.compile('<name>(.+?)</name>.+?url>(.+?)</url>.+?image>(.+?)</image>.+?type>(.+?)</type>.+?img>(.+?)</img>.+?season>(.+?)</season>.+?episode>(.+?)</episode>.+?genre>(.+?)</genre>.+?plot>(.+?)</plot>.+?tvshow>(.+?)</tvshow>',re.DOTALL).findall(item)
		for name,url,image,type,img,season,episode,genre,plot,tvshow in channels:
			
			if type == '3':
				addmenu(name,url,type,image)
			else:
				addChannelTV(name,url,type,image,type,img,season,episode,genre,plot,tvshow)				
def GetDataMovie(url):
	Data=GetUrl(url)
	result=re.compile('<channel>(.+?)</channel>',re.DOTALL).findall(Data)
	for item in result:
		channels=re.compile('<name>(.+?)</name>.+?url>(.+?)</url>.+?image>(.+?)</image>.+?type>(.+?)</type>.+?img>(.+?)</img>.+?genre>(.+?)</genre>.+?plot>(.+?)</plot>.+?year>(.+?)</year>',re.DOTALL).findall(item)
		for name,url,image,type,img,genre,plot,year in channels:
			
			if type == '3':
				addmenu(name,url,type,image)
			else:
				addChannelMovie(name,url,type,image,type,img,genre,plot,year)
def findit(title):
	hsh = pProtect(pword)
	Gurl = "http://www.pjalpha.co.nf/access.php?usr="+user+"&xs="+hsh+"&tv=1"
	query = GetHome(Gurl)
	query = query+title
	Data = GetUrl(query)
	result=re.compile('<channel>(.+?)</channel>',re.DOTALL).findall(Data)
	for item in result:
		channels=re.compile('<name>(.+?)</name>.+?url>(.+?)</url>.+?image>(.+?)</image>.+?type>(.+?)</type>',re.DOTALL).findall(item)
		for name,url,image,type in channels:
			if type == '0':
				player2(url, name, image)
			if type == '1':
				player3(url, name, image)
			if type == '2':
				player(url, name, image)
	return channels

def findit2(title):
	hsh = pProtect(pword)
	Gurl = "http://www.pjalpha.co.nf/access.php?usr="+user+"&xs="+hsh+"&mv=1"
	query = GetHome(Gurl)
	query = query+title
	Data = GetUrl(query)
	return Data		
	
def addmenu(name,url,mode,iconimage):
	data=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&title="+urllib.quote_plus(name)+"&img="+urllib.quote_plus(iconimage)
	DI=True
	li=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	li.setInfo( type="Video", infoLabels={ "Title": name} )
	conmenu=[]
	conmenu.append(('','XBMC.RunPlugin(%s?mode=fav&title=%s&img=%s)'% (sys.argv[0],name,iconimage)))
	li.addContextMenuItems(conmenu, replaceItems=True)
	DI=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=data,listitem=li,isFolder=True)			
			
def addChannel(name,url,mode,iconimage,type,plot):
	data=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+urllib.quote_plus(mode)+"&title="+urllib.quote_plus(name)+"&img="+urllib.quote_plus(iconimage)
	DI=True
	li=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	li.setInfo( type="Video", infoLabels={ "title": name, "plot": name, "genre": name, "episode" : "10", "totalepisodes" : "10", "tvshowtitle" : "Hello", "year" : "1999", "episodename" : "test" } )
	li.setProperty('fanart_image', iconimage)
	conmenu=[]
	conmenu.append(('Report as Not Working','XBMC.RunPlugin(%s?mode=nwl&title=%s&img=%s&url=%s&pw=%s)'% (sys.argv[0],name,iconimage,user,pword)))
	
	li.addContextMenuItems(conmenu, replaceItems=True)
	li.setProperty("IsPlayable","true")
	DI=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=data,listitem=li,isFolder=False)
	xbmcplugin.setContent(handle=int( sys.argv[ 1 ] ), content="tvshows")
	return DI
	
def addChannelTV(name,url,mode,iconimage,type,plot,season,episode,genre,desc,tvshow):
	data=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+urllib.quote_plus(mode)+"&title="+urllib.quote_plus(name)+"&img="+urllib.quote_plus(iconimage)
	DI=True
	pl=episode+". "+plot
	li=xbmcgui.ListItem(pl, iconImage=iconimage, thumbnailImage=iconimage)
	li.setInfo( type="Video", infoLabels={ "title": name, "plot": desc, "genre": genre, "season" : season, "episode" : episode, "tvshowtitle" : tvshow, "year" : "1999", 'aired': "1999"} )
	li.setProperty('fanart_image', iconimage)
	conmenu=[]
	conmenu.append(('Report as Not Working','XBMC.RunPlugin(%s?mode=nwl&title=%s&img=%s&url=%s&pw=%s)'% (sys.argv[0],name,iconimage,user,pword)))
	
	li.addContextMenuItems(conmenu, replaceItems=True)
	li.setProperty("IsPlayable","true")
	DI=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=data,listitem=li,isFolder=False)
	xbmcplugin.setContent(handle=int( sys.argv[ 1 ] ), content="episodes")
	return DI

def addChannelMovie(name,url,mode,iconimage,type,imge,genre,plot,year):
	data=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+urllib.quote_plus(mode)+"&title="+urllib.quote_plus(name)+"&img="+urllib.quote_plus(iconimage)
	DI=True
	li=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	li.setInfo( type="Video", infoLabels={ "title": name, "plot": plot, "genre": genre, "year" : year, "director" : "unknown", "writer" : "unknown"} )
	li.setProperty('fanart_image', iconimage)
	conmenu=[]
	conmenu.append(('Report as Not Working','XBMC.RunPlugin(%s?mode=nwl&title=%s&img=%s&url=%s&pw=%s)'% (sys.argv[0],name,iconimage,user,pword)))
	
	li.addContextMenuItems(conmenu, replaceItems=True)
	li.setProperty("IsPlayable","true")
	DI=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=data,listitem=li,isFolder=False)
	xbmcplugin.setContent(handle=int( sys.argv[ 1 ] ), content="movies")
	return DI		   


def player(url,name,iconimage):

	if urlresolver.HostedMediaFile(url).valid_url():
		streamurl = urlresolver.HostedMediaFile(url).resolve()
	else: streamurl=url
	player=xbmc.Player()
	details=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	player.play(streamurl,details)

def player2(url,name,iconimage):

	streamurl=liveresolver.resolve(url)
	player=xbmc.Player()
	details=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	player.play(streamurl,details)

def player3(url,name,iconimage):

	player=xbmc.Player()
	details=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	player.play(url,details)

			
if mode is None:
	if user == "":
			dialog = xbmcgui.Dialog()
			dialog.ok("Username", "Your username is blank", "Please enter the username and password","& Restart Add-on")
			inp = dialog.input('Please enter username', type=xbmcgui.INPUT_ALPHANUM)
			_addon.setSetting('user', inp)
			inp = dialog.input('Please enter password', type=xbmcgui.INPUT_ALPHANUM)
			_addon.setSetting('pass', inp)
	

	hsh = pProtect(pword)
	Gurl = "http://www.pjalpha.co.nf/access.php?usr="+user+"&xs="+hsh
	HomeUrl = GetHome(Gurl)
	GetData(HomeUrl)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))
	xbmc.executebuiltin('Container.SetViewMode(500)')
	
	
elif mode[0] == '0':
    url = args['url'][0]
    title = args['title'][0]
    img = args['img'][0]
	
    resolved = liveresolver.resolve(url)
    li = xbmcgui.ListItem(title, path=resolved)
    li.setThumbnailImage(img)
    li.setLabel(title)
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
elif mode[0] == '2':
	url = args['url'][0]
	img =['img'][0]
	title = args['title'][0]
	if urlresolver.HostedMediaFile(url).valid_url():
		streamurl = urlresolver.HostedMediaFile(url).resolve()
	else: streamurl=url
	li = xbmcgui.ListItem(title, path=streamurl)
	li.setThumbnailImage(img)
	li.setLabel(title)
	li.setProperty('IsPlayable', 'true')
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
	
elif mode[0] == '1':
    url = args['url'][0]
    title = args['title'][0]
    img = args['img'][0]
	
    resolved = url
    li = xbmcgui.ListItem(title, path=resolved)
    li.setThumbnailImage(img)
    li.setLabel(title)
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)

elif mode[0] == '3':
	url = args['url'][0]
	GetData(url)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))
	xbmc.executebuiltin('Container.SetViewMode(500)')

elif mode[0] == '4':
	url = args['url'][0]
	GetDataTV(url)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))
	xbmc.executebuiltin('Container.SetViewMode(515)')
elif mode[0] == '5':
	url = args['url'][0]
	GetDataMovie(url)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))
	xbmc.executebuiltin('Container.SetViewMode(508)')	
elif mode[0] == 'play4':
	title = args['title'][0]
	channels = findit(title)
	

elif mode[0] == 'play5':
	title = args['title'][0]
	channels = findit(title)
elif mode[0] == 'play6':
	title = args['title'][0]
	url = findit2(title)
	img = args['img'][0]
	player(url, title, img)
elif mode[0] == 'nwl':
	title = args['title'][0]
	img = args['img'][0]
	user = args['url'][0]
	pword = args['pw'][0]
	hsh = pProtect(pword)
	Gurl = "http://www.pjalpha.co.nf/access.php?usr="+user+"&xs="+hsh+"&rdl=1"
	rdlUrl = GetHome(Gurl)
	senddata = rdlUrl+"?rdl="+title
	res = GetUrl(senddata)
	xbmc.executebuiltin('Notification(Update, Reported as not working.)')
	
	
	
