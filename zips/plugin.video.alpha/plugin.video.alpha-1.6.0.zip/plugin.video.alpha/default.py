import xbmc,xbmcaddon,xbmcgui,xbmcplugin,urllib,urllib2,os,re,sys,urlresolver,liveresolver,urlparse,hashlib
from addon.common.addon import Addon

addon = Addon('plugin.video.alpha', sys.argv)
AddonPath = addon.get_path()
args = urlparse.parse_qs(sys.argv[2][1:])
mode = args.get('mode', None)
favourites = xbmc.translatePath(os.path.join('special://home/userdata', 'favourites.xml'))
user=xbmcplugin.getSetting(int(sys.argv[1]), 'user')
pword=xbmcplugin.getSetting(int(sys.argv[1]), 'pass')
_addon = xbmcaddon.Addon()

def pProtect(pw):
	ret = hashlib.sha224(pw).hexdigest()
	return ret
def GetUrl(Durl):
		Durl=Durl.replace(' ','%20')
		request = urllib2.Request(Durl)
		request.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
		handle = urllib2.urlopen(request)
		content = handle.read()  
		handle.close()
		return content
		
def GetHome(url):
	Data=GetUrl(url)
	result =re.compile('<channel>(.+?)</channel>',re.DOTALL).findall(Data)
	for item in result:
		channels=re.compile('<url>(.+?)</url>',re.DOTALL).findall(item)
		for url in channels:
			val=url
		return url
			
def GetData(url):
	Data=GetUrl(url)
	result=re.compile('<channel>(.+?)</channel>',re.DOTALL).findall(Data)
	for item in result:
		channels=re.compile('<name>(.+?)</name>.+?url>(.+?)</url>.+?image>(.+?)</image>.+?type>(.+?)</type>',re.DOTALL).findall(item)
		for name,url,image,type in channels:
			
			if type == '3':
				addmenu(name,url,type,image)
			else:
				addChannel(name,url,type,image,type)
				

def findit(title):
	query = 'http://loopy.16mb.com/alpha.php?sch=t&name='+title
	Data = GetUrl(query)
	return Data

def findit2(title):
	query = 'http://loopy.16mb.com/alpha.php?sch=m&name='+title
	Data = GetUrl(query)
	return Data		
	
def addmenu(name,url,mode,iconimage):
	data=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&title="+urllib.quote_plus(name)+"&img="+urllib.quote_plus(iconimage)
	DI=True
	li=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	li.setInfo( type="Video", infoLabels={ "Title": name} )
	conmenu=[]
	conmenu.append(('','XBMC.RunPlugin(%s?mode=fav&title=%s&img=%s)'% (sys.argv[0],name,iconimage)))
	li.addContextMenuItems(conmenu, replaceItems=True)
	DI=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=data,listitem=li,isFolder=True)			
			
def addChannel(name,url,mode,iconimage,type):
	data=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+urllib.quote_plus(mode)+"&title="+urllib.quote_plus(name)+"&img="+urllib.quote_plus(iconimage)
	DI=True
	li=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	li.setInfo( type="Video", infoLabels={ "Title": name} )
	conmenu=[]
	mo = 'fav'+type
	conmenu.append(('Add to favourites','XBMC.RunPlugin(%s?mode=%s&title=%s&img=%s)'% (sys.argv[0],mo,name,iconimage)))
	
	li.addContextMenuItems(conmenu, replaceItems=True)
	li.setProperty("IsPlayable","true")
	DI=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=data,listitem=li,isFolder=False)
	return DI
	

def favs(title, image, mode):
	image=image.replace(' ','%20')
	title2=title.replace(' ','%20')
	if mode == 1:
		entry='<favourite name=\"'+title+'\" thumb=\"'+image+'\">ActivateWindow(10025,&quot;plugin://plugin.video.alpha/?url=&amp;title='+title2+'&amp;mode=menu&amp;img='+image+'&quot;)</favourite>'
	if mode == 2:
		entry='<favourite name=\"'+title+'\" thumb=\"'+image+'\">ActivateWindow(10025,&quot;plugin://plugin.video.alpha/?url=&amp;title='+title2+'&amp;mode=play4&amp;img='+image+'&quot;)</favourite>'
	if mode == 3:
		entry='<favourite name=\"'+title+'\" thumb=\"'+image+'\">ActivateWindow(10025,&quot;plugin://plugin.video.alpha/?url=&amp;title='+title2+'&amp;mode=play5&amp;img='+image+'&quot;)</favourite>'
	if mode == 4:
		entry='<favourite name=\"'+title+'\" thumb=\"'+image+'\">ActivateWindow(10025,&quot;plugin://plugin.video.alpha/?url=&amp;title='+title2+'&amp;mode=play6&amp;img='+image+'&quot;)</favourite>'
	lines = []
	with open(favourites) as infile:
		for line in infile:
			if line.strip() == '</favourites>':
				line = line.replace('</favourites>', '')
				lines.append(line)
			else:
				lines.append(line)
	with open(favourites, 'w') as outfile:
		for line in lines:
			outfile.write(line)
	
	openfav = open(favourites,'a')
	openfav.write(entry)
	openfav.write("\n")
	openfav.write("</favourites>")
	openfav.close()
	   


def player(url,name,iconimage):

	if urlresolver.HostedMediaFile(url).valid_url():
		streamurl = urlresolver.HostedMediaFile(url).resolve()
	else: streamurl=url
	player=xbmc.Player()
	details=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	player.play(streamurl,details)

def player2(url,name,iconimage):

	streamurl=liveresolver.resolve(url)
	player=xbmc.Player()
	details=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	player.play(streamurl,details)

def player3(url,name,iconimage):

	player=xbmc.Player()
	details=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	player.play(url,details)
if user == "":
			dialog = xbmcgui.Dialog()
			dialog.ok("Username", "Your username is blank", "Please enter the username and password","& Restart Add-on")
			inp = dialog.input('Please enter username', type=xbmcgui.INPUT_ALPHANUM)
			_addon.setSetting('user', inp)
			inp = dialog.input('Please enter password', type=xbmcgui.INPUT_ALPHANUM)
			_addon.setSetting('pass', inp)
			
if mode is None:
	hsh = pProtect(pword)
	Gurl = "http://www.pjalpha.co.nf/access.php?usr="+user+"&xs="+hsh
	HomeUrl = GetHome(Gurl)
	GetData(HomeUrl)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))
	addon.end_of_directory()
	
elif mode[0] == '0':
    url = args['url'][0]
    title = args['title'][0]
    img = args['img'][0]
	
    resolved = liveresolver.resolve(url)
    li = xbmcgui.ListItem(title, path=resolved)
    li.setThumbnailImage(img)
    li.setLabel(title)
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
elif mode[0] == '2':
	url = args['url'][0]
	img =['img'][0]
	title = args['title'][0]
	if urlresolver.HostedMediaFile(url).valid_url():
		streamurl = urlresolver.HostedMediaFile(url).resolve()
	else: streamurl=url
	li = xbmcgui.ListItem(title, path=streamurl)
	li.setThumbnailImage(img)
	li.setLabel(title)
	li.setProperty('IsPlayable', 'true')
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
	
elif mode[0] == '1':
    url = args['url'][0]
    title = args['title'][0]
    img = args['img'][0]
	
    resolved = url
    li = xbmcgui.ListItem(title, path=resolved)
    li.setThumbnailImage(img)
    li.setLabel(title)
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)

elif mode[0] == '3':
	url = args['url'][0]
	GetData(url)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))
elif mode[0] == 'fav':
	title = args['title'][0]
	img = args['img'][0]
	favs(title,img, 1)
elif mode[0] == 'fav0':
	title = args['title'][0]
	img = args['img'] [0]
	favs(title,img, 2)
elif mode[0] == 'fav1':
	title = args['title'][0]
	img = args['img'] [0]
	favs(title,img, 3)
elif mode[0] == 'fav2':
	title = args['title'][0]
	img = args['img'] [0]
	favs(title,img, 4)
elif mode[0] == 'play4':
	title = args['title'][0]
	url = findit(title)
	img = args['img'][0]
	player2(url, title, img)
elif mode[0] == 'play5':
	title = args['title'][0]
	url = findit(title)
	img = args['img'][0]
	player3(url, title, img)
elif mode[0] == 'play6':
	title = args['title'][0]
	url = findit2(title)
	img = args['img'][0]
	player(url, title, img)
	
	
	
