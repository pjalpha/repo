import xbmcaddon

import xbmcgui
 
import urllib, os,re,urllib2
import xbmc
import shutil
import sqlite3
import xbmcplugin



# make connection to existing db

conn = sqlite3.connect('C:\Users\Loopy\Desktop\source.db')
c = conn.cursor()

# Set New Login details

UserN=xbmcplugin.getSetting(int(sys.argv[1]), 'Duser')

PWord=xbmcplugin.getSetting(int(sys.argv[1]), 'Dpass')


# Change to new Login details

UserNameSend = "UPDATE custom_stream_url SET stream_url = REPLACE(stream_url,'projectalpha%40myway.com','" + UserN + "')"
PasswordSend = "UPDATE custom_stream_url SET stream_url = REPLACE(stream_url,'roxanne1','" + PWord + "')"


# update field

c.execute(UserNameSend) 
c.execute(PasswordSend) 

# Save the changes

conn.commit()


# close connection
conn.close()