import xbmcaddon

import xbmcgui
 
import urllib, os,re,urllib2
import xbmc
import shutil
import BeautifulSoup
import mysql.connector


cnx = mysql.connector.connect(user='1958546_pja', password='pjalpha',
                              host='fdb12.biz.nf',
                              database='tvguide')

cursor = db.cursor()
 query = ("SELECT password FROM tvguide WHERE index = 1")
 cursor.execute(query)
 line4 = cursor.fetchall()
 cursor.close()
 db.close()

addon       = xbmcaddon.Addon()

addonname   = addon.getAddonInfo('name')
 


line1 = "Project Alpha  -  Update!"

line2 = "We will now update your TV Guide"

 


xbmcgui.Dialog().ok(addonname, line1, line2, line3)