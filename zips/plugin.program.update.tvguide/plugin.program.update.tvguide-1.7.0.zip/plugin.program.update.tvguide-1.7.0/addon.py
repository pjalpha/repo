import pyxbmct.addonwindow as pyxbmct 
import xbmcaddon
import xbmcgui
import urllib, os,re,urllib2
import xbmc
import shutil
import sqlite3
import xbmcplugin
from BeautifulSoup import BeautifulSoup

# Get addon details
_addon = xbmcaddon.Addon()
_addon_path = _addon.getAddonInfo('path')
alignment=pyxbmct.ALIGN_CENTER

# Load Settings
dexuser=xbmcplugin.getSetting(int(sys.argv[1]), 'Duser')
dexpword=xbmcplugin.getSetting(int(sys.argv[1]), 'Dpass')
pjaEmail=xbmcplugin.getSetting(int(sys.argv[1]), 'usern')
pjaPword=xbmcplugin.getSetting(int(sys.argv[1]), 'passw')


def DownloaderClass(url,dest):
    dp = xbmcgui.DialogProgress()
    dp.create("Downloading TV Guide","Downloading File")
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
 
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        print percent
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled(): 
        print "DOWNLOAD CANCELLED" # need to get this part working
        del window
	dp.close()

def DownloadedDexter():
	line1 = "[B][COLOR red]Down Dexter Channels:[/COLOR][/B]"
	line2 = "[B][COLOR red]---------------------------------------------------------------------[/COLOR][/B]"
 

	Durl = "http://50.7.136.90/stats.php"
	request = urllib2.Request(Durl)

	handle = urllib2.urlopen(request)

	content = handle.read()

	splitted_page = content.split("Streams Experiencing issues</caption>", 1);
	splitted_page = splitted_page[1].split("</tbody></table>", 1)


	soup = BeautifulSoup(splitted_page[0])
	trlist = soup.find("tr")

	result = "[COLOR blue]"

	for td in soup:
		value = td.findAll("td")
	
	
		for value2 in value:
			rn = value2.text
			result += rn
			result += "-"

	result += "[/COLOR]"
	xbmcgui.Dialog().ok(line1, line2, result)
	
def Create_main(DownloadedNews, Upd):
	MainWindow = pyxbmct.AddonDialogWindow('Project @lpha TV Guide 1.7.0')
	MainWindow.setGeometry(730, 500, 6, 5)
	
	# Insert Image
	MainWindow.image = pyxbmct.Image(os.path.join(_addon_path, 'black.jpg'))
        MainWindow.placeControl(MainWindow.image, 0, 0, 6, 5)

	# News
	MainWindow.fade_label = pyxbmct.FadeLabel()
        MainWindow.placeControl(MainWindow.fade_label, 0, 1, columnspan=3)
        MainWindow.fade_label.addLabel(DownloadedNews)
		
	Update = pyxbmct.Label(Upd, font='font12', alignment=pyxbmct.ALIGN_CENTER)
	MainWindow.placeControl(Update, 5, 4)
	
	
	# Create Buttons
	CloseBut = pyxbmct.Button('Close')
	MainWindow.placeControl(CloseBut, 5, 1, columnspan=3)

	FixBut = pyxbmct.Button('Fix Problem')
	MainWindow.placeControl(FixBut, 2, 1, columnspan=3)

	GuideBut = pyxbmct.Button('TV Guides')
	MainWindow.placeControl(GuideBut, 3, 1, columnspan=3)

	SettingsBut = pyxbmct.Button('Settings')
	MainWindow.placeControl(SettingsBut, 1, 1, columnspan=3)

	# Set Navigation Control
	SettingsBut.controlUp(CloseBut)
	SettingsBut.controlDown(FixBut)
	FixBut.controlUp(SettingsBut)
	FixBut.controlDown(GuideBut)
	GuideBut.controlUp(FixBut)
	GuideBut.controlDown(CloseBut)
	CloseBut.controlUp(GuideBut)
	CloseBut.controlDown(SettingsBut)
	MainWindow.setFocus(CloseBut)

	# Set Button functions
	MainWindow.connect(CloseBut, MainWindow.close)
	MainWindow.connect(GuideBut,lambda: TV_Guides())
	MainWindow.connect(SettingsBut,lambda: SettingsMenu())
	MainWindow.connect(FixBut,lambda: FixMenu())


	MainWindow.connect(pyxbmct.ACTION_NAV_BACK, MainWindow.close)
	MainWindow.doModal()
	
	del MainWindow

def TV_Guides():
	DownloadedDexter()
	
	# Set Url for Download Guide
	url2 ='http://www.pjalpha.co.nf/source.db'
	
	
	# Create a window instance. (Title)
	window = pyxbmct.AddonDialogWindow('')

	# Set the window width, height and the grid resolution: 3 rows, 3 columns.
	window.setGeometry(700, 500, 3, 3)

	window.image = pyxbmct.Image(os.path.join(_addon_path, 'black.jpg'))
        window.placeControl(window.image, 0, 0, 3, 3)
	
	# Create a text label.
	label = pyxbmct.Label('[B][COLOR yellow]Please Select your TV Guide.[/COLOR][/B]', font='font16', alignment=pyxbmct.ALIGN_CENTER)

	# Place the label on the window grid.
	window.placeControl(label, 0, 0, columnspan=3)

	# Create a button.
	button = pyxbmct.Button('Kids Tv Guide')
	button2 = pyxbmct.Button('Tv Guide')
	button3 = pyxbmct.Button('Dexter Tv Guide')
	button4 = pyxbmct.Button('EXIT')

	# Place the button on the window grid.
	window.placeControl(button, 1, 0)
	window.placeControl(button2, 1, 1)
	window.placeControl(button3, 1, 2)
	window.placeControl(button4, 2, 1)

	# Set Navigation Control
	button.controlRight(button2)
	button2.controlRight(button3)
	button3.controlLeft(button2)
	button2.controlLeft(button)
	button2.controlDown(button4)
	button4.controlUp(button2)

	# Set initial focus on the button.
	window.setFocus(button4)

	# Connect the button to a function.
	window.connect(button, lambda: KidsTV())
	window.connect(button2,lambda: DownloaderClass(url2,"/sdcard/android/data/org.xbmc.kodi/files/.kodi/userdata/addon_data/script.renegadestv/source.db"))
	window.connect(button3,lambda: DexTV())
	window.connect(button4, window.close)

	# Connect a key action to a function.
	window.connect(pyxbmct.ACTION_NAV_BACK, window.close)
	
	# Show the created window.
	window.doModal()

	# Delete the window instance when it is no longer used.
	
	UpdateDexterGuide()
	del window

def UpdateDexterGuide():
	
	conn = sqlite3.connect('/sdcard/android/data/org.xbmc.kodi/files/.kodi/userdata/addon_data/script.renegadestv/source.db')
	c = conn.cursor()

	# Set New Login details
	UserN=xbmcplugin.getSetting(int(sys.argv[1]), 'Duser')
	PWord=xbmcplugin.getSetting(int(sys.argv[1]), 'Dpass')

	# Change to new Login details
	UserNameSend = "UPDATE custom_stream_url SET stream_url = REPLACE(stream_url,'projectalpha%40myway.com','" + UserN + "')"
	PasswordSend = "UPDATE custom_stream_url SET stream_url = REPLACE(stream_url,'roxanne1','" + PWord + "')"

	# update field
	c.execute(UserNameSend) 
	c.execute(PasswordSend) 

	# Save the changes
	conn.commit()

	# close connection
	conn.close()
	xbmc.executebuiltin('Notification(Update, Dexter TV Guide Updated.)')
	
def SaveSettings(RetUser, RetPW, RetPJUN, RetPJPW):
	_addon.setSetting('Duser', RetUser)
	_addon.setSetting('Dpass', RetPW)
	_addon.setSetting('usern', RetPJUN)
	_addon.setSetting('passw', RetPJPW)
	xbmc.executebuiltin('Notification(Update, Settings Successfully Updated.)')
	
def SettingsMenu():
	
	
	
	# Create Window
	SettingsWindow = pyxbmct.AddonDialogWindow('')
	SettingsWindow.setGeometry(750, 500, 9, 4)
	
	SettingsWindow.image = pyxbmct.Image(os.path.join(_addon_path, 'black.jpg'))
        SettingsWindow.placeControl(SettingsWindow.image, 0, 0, 9, 4)
	
	# Set Controls
	Title = pyxbmct.Label('[B][COLOR yellow]Settings[/COLOR][/B]', font='font16', alignment=pyxbmct.ALIGN_CENTER )
	SettingsWindow.placeControl(Title, 0, 1, columnspan=2)
	
	Title2 = pyxbmct.Label('Please enter your details below, The Dexter username is the email', alignment=pyxbmct.ALIGN_CENTER )
	SettingsWindow.placeControl(Title2, 1, 0, columnspan=4)
	
	Title3 = pyxbmct.Label('you used to register with Dexter!', alignment=pyxbmct.ALIGN_CENTER )
	SettingsWindow.placeControl(Title3, 2, 0, columnspan=4)
	
	DexUser = pyxbmct.Edit('', _alignment=pyxbmct.ALIGN_CENTER)
	SettingsWindow.placeControl(DexUser, 6, 1, columnspan=2)
	DexLabel = pyxbmct.Label('Dexter Username:', alignment=pyxbmct.ALIGN_RIGHT)
	SettingsWindow.placeControl(DexLabel, 6, 0)
	DexPW = pyxbmct.Edit('', _alignment=pyxbmct.ALIGN_CENTER, isPassword=True)
	SettingsWindow.placeControl(DexPW, 7, 1, columnspan=2)
	DexPWL = pyxbmct.Label('Dexter Password:', alignment=pyxbmct.ALIGN_RIGHT)
	SettingsWindow.placeControl(DexPWL, 7, 0)
	PW = pyxbmct.Edit('',  _alignment=pyxbmct.ALIGN_CENTER, isPassword=True)
	SettingsWindow.placeControl(PW, 5, 1, columnspan=2)
	PWL = pyxbmct.Label('PJA Password:', alignment=pyxbmct.ALIGN_RIGHT)
	SettingsWindow.placeControl(PWL, 5, 0)
	Email = pyxbmct.Edit('', _alignment=pyxbmct.ALIGN_CENTER)
	SettingsWindow.placeControl(Email, 4, 1, columnspan=2)
	Lbl = pyxbmct.Label('Email:', alignment=pyxbmct.ALIGN_RIGHT)
	SettingsWindow.placeControl(Lbl, 4, 0)
	
	CancelButton = pyxbmct.Button('Save & Close')
	SettingsWindow.placeControl(CancelButton, 8, 2)
	
	# Additional Settings
	
	DexUser.setText(dexuser)
	DexPW.setText(dexpword)
	PW.setText(pjaPword)
	Email.setText(pjaEmail)
	
	# Set Navigation
	
	
	CancelButton.controlUp(DexPW)
	DexPW.controlDown(CancelButton)
	DexPW.controlUp(DexUser)
	DexUser.controlDown(DexPW)
	DexUser.controlUp(PW)
	PW.controlDown(DexUser)
	PW.controlUp(Email)
	Email.controlDown(PW)
	Email.controlUp(CancelButton)
	
	SettingsWindow.setFocus(CancelButton)
	
	
	# Set Functions
	SettingsWindow.connect(CancelButton, SettingsWindow.close)	
	SettingsWindow.connect(pyxbmct.ACTION_NAV_BACK, SettingsWindow.close)
	
	
	# Build
	SettingsWindow.doModal()
	SaveSettings(DexUser.getText(), DexPW.getText(), Email.getText(), PW.getText())
	del SettingsWindow
	xbmcgui.Dialog().ok("Restart", "Please Restart Update TV Guide before continuing!")
	
def retrieveNews():
		newsUrl = "http://www.pjalpha.co.nf/news.xml"
		request = urllib2.Request(newsUrl)
		handle = urllib2.urlopen(request)

		content = handle.read()

		splitted_page = content.split("<news>", 1);
		splitted_page = splitted_page[1].split("</news>", 1)
		FullRet = "[B][COLOR yellow]Welcome to Project @lpha Update TV Guide                                                         [/COLOR][COLOR aqua]" +splitted_page[0] +"[/COLOR][/B]"
		return FullRet

def UpdatedDate():	
	newsUrl = "http://www.pjalpha.co.nf/news.xml"
	request = urllib2.Request(newsUrl)
	handle = urllib2.urlopen(request)

	content = handle.read()

	splitted_page = content.split("<updated>", 1);
	splitted_page = splitted_page[1].split("</updated>", 1)
	FullRet = "Last Updated:[COLOR aqua]" +splitted_page[0] +"[/COLOR]"
	return FullRet

def KidsTV():
	url ='http://www.pjalpha.co.nf/kids/source.db'
	Set ='http://www.pjalpha.co.nf/kids/settings.xml'
	
	DownloaderClass(url,"/sdcard/android/data/org.xbmc.kodi/files/.kodi/userdata/addon_data/script.renegadestv/source.db")
	DownloaderClass(Set,"/sdcard/android/data/org.xbmc.kodi/files/.kodi/userdata/addon_data/script.renegadestv/settings.xml")
	
def DexTV():
	url ='http://www.pjalpha.co.nf/Adult/source.db'
	Set ='http://www.pjalpha.co.nf/Adult/settings.xml'
	
	DownloaderClass(url,"/sdcard/android/data/org.xbmc.kodi/files/.kodi/userdata/addon_data/script.renegadestv/source.db")
	DownloaderClass(Set,"/sdcard/android/data/org.xbmc.kodi/files/.kodi/userdata/addon_data/script.renegadestv/settings.xml")

def FixMenu():
	xbmcgui.Dialog().ok("Information", "This feature will be available in Version 1.8")

# Download News
DownloadedNewsT = retrieveNews()
Upd = UpdatedDate()

if dexuser == "":
	SettingsMenu()
else:
	if dexpword == "":
		SettingsMenu()
	else:
		Create_main(DownloadedNewsT, Upd)



	

