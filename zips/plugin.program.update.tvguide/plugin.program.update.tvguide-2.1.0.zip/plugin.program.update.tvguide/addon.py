import xbmcaddon
import xbmcgui
import urllib, os,re,urllib2
import xbmc
import shutil
import sqlite3
import xbmcplugin
from BeautifulSoup import BeautifulSoup
import datetime
import time
import hashlib


_addon = xbmcaddon.Addon()
_addon_path = _addon.getAddonInfo('path')
month = datetime.datetime.now().strftime("%m")
date = time.strftime("%d%m%y")
_addonr = xbmcaddon.Addon(id = 'script.renegadestv')
profilePath = xbmc.translatePath(_addonr.getAddonInfo('profile'))
dexuser=xbmcplugin.getSetting(int(sys.argv[1]), 'Duser')
dexpword=xbmcplugin.getSetting(int(sys.argv[1]), 'Dpass')
pjaPword=xbmcplugin.getSetting(int(sys.argv[1]), 'passw')
updatevalue=xbmcplugin.getSetting(int(sys.argv[1]), 'Update')
lastupdated=xbmcplugin.getSetting(int(sys.argv[1]), 'lastupdated')
profile = xbmc.translatePath( 'special://profile//')

def DownloaderClass(url,dest):
    dp = xbmcgui.DialogProgress()
    dp.create("Downloading","Downloading File")
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
 
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        print percent
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled(): 
        print "DOWNLOAD CANCELLED" 
        del window
	dp.close()

def UpdateGuide():
	
	file = os.path.join(profilePath, 'source.db')
	conn = sqlite3.connect(file)
	c = conn.cursor()
	UserN=xbmcplugin.getSetting(int(sys.argv[1]), 'Duser')
	PWord=xbmcplugin.getSetting(int(sys.argv[1]), 'Dpass')
	UserNameSend = "UPDATE custom_stream_url SET stream_url = REPLACE(stream_url,'projectalpha@myway.com','" + UserN + "')"
	PasswordSend = "UPDATE custom_stream_url SET stream_url = REPLACE(stream_url,'roxanne1','" + PWord + "')"
	UserNameSenda = "UPDATE custom_stream_url SET stream_url = REPLACE(stream_url,'projectalpha%40myway.com','" + UserN + "')"
	command = "UPDATE custom_stream_url SET stream_url = REPLACE(stream_url,';','')"
	c.execute(UserNameSend) 
	c.execute(PasswordSend)
	c.execute(UserNameSenda)
	c.execute(command) 
	conn.commit()
	conn.close()
	xbmc.executebuiltin('Notification(Update, TV Guide Updated.)')
	

def retrieveData(opening, closing, Url):
	try:	
		request = urllib2.Request(Url)
		handle = urllib2.urlopen(request)
		content = handle.read()
		splitted_page = content.split(opening, 1);
		splitted_page = splitted_page[1].split(closing, 1)
		FullRet = splitted_page[0]
		return FullRet
	except:
		return "Unable to retrieve data"

def KidsTV():
	url = DataUrl + 'kids/update.xml'
	Set = DataUrl + 'kids/settings.xml'
	ldate = checklastdate()
	dbdate = getinfo('fifth')
	file = os.path.join(_addon_path, 'update.xml')
	file2 = os.path.join(profilePath, 'settings.xml')
	try:
		DownloaderClass(url, file)
		DownloaderClass(Set, file2)
		if dbdate != ldate:
			updatesource()
			reset_channelsON()
			channelON()
			UpdateGuide()
			updatedatabase('third', date)
			updatedatabase('fifth', ldate)
		else:
			xbmc.executebuiltin('Notification(Update, TV Guide up to date.)')	
			updatedatabase('third', date)
	except:
		xbmcgui.Dialog().ok("Error", "The server is currently down \n Please try later or visit: \nhttp://pjalpha.byethost14.com/mybb/")
		updatedatabase('third', date)
	
def ATV():
	xbmcgui.Dialog().ok("Update", "We will now update your TV Guide to the new program", "This may take a few minutes")
	Set = DataUrl + 'Adult/settings.xml'
	src = DataUrl + 'Adult/source.db'
	try:
		file3 = os.path.join(profilePath, 'source.db')
		file2 = os.path.join(profilePath, 'settings.xml')
		DownloaderClass(src, file3)
		DownloaderClass(Set, file2)
		UpdateGuide()
		updatedatabase('third', date)
		updatedatabase('fifth', date)
	except:
		xbmcgui.Dialog().ok("Error", "The server is currently down \n Please try later or visit: \nhttp://pjalpha.byethost14.com/mybb/")
		updatedatabase('third', date)

def getinfo(input):
	file = os.path.join(_addon_path, 'addon.db')
	conn = sqlite3.connect(file)
	c = conn.cursor()
	query = "SELECT "+ input +" FROM tvguide WHERE username='test@test.com'"
	c.execute(query) 
	answer = c.fetchone()
	
	for rows in answer:
		ret = rows

	conn.close()
	return ret
	

def pProtect(pw):
	ret = hashlib.sha224(pw).hexdigest()
	return ret

def updatedatabase(selectrow, changeto):
	file = os.path.join(_addon_path, 'addon.db')
	conn = sqlite3.connect(file)
	c = conn.cursor()
	c.execute("UPDATE tvguide SET " + selectrow + " = '" + changeto + "' WHERE username='test@test.com'")
	conn.commit()
	conn.close()

def CLEARCACHE(): #daily
   
    xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
    if os.path.exists(xbmc_cache_path)==True:    
        for root, dirs, files in os.walk(xbmc_cache_path):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
				
                for f in files:
                    try:
                        os.unlink(os.path.join(root, f))
                    except:
                        pass
                for d in dirs:
                    try:
                        shutil.rmtree(os.path.join(root, d))
                    except:
                         pass
                xbmc.executebuiltin('Notification(Maintenance, Cache cleared)')                
            else:
                pass
    downloader_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/script.module.simple.downloader'), '')
    if os.path.exists(downloader_cache_path)==True:    
        for root, dirs, files in os.walk(downloader_cache_path):
            file_count = 0
            file_count += len(files)
                
            if file_count > 0:
    
                for f in files:
                    os.unlink(os.path.join(root, f))
                for d in dirs:
                    shutil.rmtree(os.path.join(root, d))
                xbmc.executebuiltin('Notification(Maintenance, Cache2 cleared)')                
            else:
                pass
 
def CLEARTHUMBS():#monthly
   
    xbmc_cache_path = os.path.join(xbmc.translatePath('special://profile/Thumbnails'), '')
    if os.path.exists(xbmc_cache_path)==True:    
        for root, dirs, files in os.walk(xbmc_cache_path):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
			                
                for f in files:
                    try:
                        os.unlink(os.path.join(root, f))
                    except:
                        pass
                for d in dirs:
                    try:
                        shutil.rmtree(os.path.join(root, d))
                    except:
                        pass
				
            else:
                pass
	xbmc.executebuiltin('Notification(Maintenance, Thumbnail pictures cleared)')            
def PURGEPACKAGES():#monthly
    packages_cache_path = xbmc.translatePath(os.path.join('special://home/addons/packages', ''))
    try:    
        for root, dirs, files in os.walk(packages_cache_path):
            file_count = 0
            file_count += len(files)
            
        
            if file_count > 0:
    
                
                for f in files:
                    os.unlink(os.path.join(root, f))
                for d in dirs:
                    shutil.rmtree(os.path.join(root, d))
                xbmc.executebuiltin('Notification(Maintenance, Packages cleared)')            
            else:
                    pass
        else:
                xbmc.executebuiltin('Notification(Maintenance, No packages to clear!)')            
    except: 
        xbmc.executebuiltin('Notification(Maintenance, Error deleting packages)')            
				
def updatePJA():
	
	CLEARTHUMBS()
	PURGEPACKAGES()
	try:
		Surl = DataUrl + 'Fix/sources.xml'
		dest = profile + 'sources.xml'
		Rss = DataUrl + 'Fix/RssFeeds.xml'
		Rssdest = profile + 'RssFeeds.xml'
		Guisettings = DataUrl + 'Fix/guisettings.xml'
		Guidest = profile + 'guisettings.xml'
		DownloaderClass(Surl, dest)
		DownloaderClass(Rss, Rssdest)
				
	except:
		xbmcgui.Dialog().ok("Error 2000", "The username %s is not registered \nTo register please visit: \nhttp://pjalpha.byethost14.com/mybb/"%(dexuser))

def updatesource():
	
	progress = xbmcgui.DialogProgress()
	progress.create('Progress Part 1 of 2', 'Updating Streams to Database.')
	
	from BeautifulSoup import BeautifulStoneSoup
	soup =  BeautifulStoneSoup((open(os.path.join(_addon_path, 'update.xml'), 'r')).read())
	xml_list = soup.findAll("group")
	size = len(xml_list)
	i = 0
	for group in xml_list:
		channel = group.channel
		stream = group.stream
		updatesoucedb(channel.text, stream.text)
		percent = min((i*100)/size, 100)
		message = "Message " + str(i) + " out of " + str(size)
		progress.update( percent, "", message, "" )
		if progress.iscanceled():
			break
		i = i + 1
	progress.close()

def updatesoucedb(channel, stream):
	file = os.path.join(profilePath, 'source.db')
	conn = sqlite3.connect(file)
	c = conn.cursor()
	checkisexsit = "SELECT channel FROM custom_stream_url WHERE channel = '" + channel + "'"
	c.execute(checkisexsit)
	answer = c.fetchone()
	if answer is None:
		insert_com = "INSERT into custom_stream_url VALUES('" + channel + "', '" + stream + "')"
		c.execute(insert_com) 
		conn.commit()
		conn.close()
	else:
		find_com = "UPDATE custom_stream_url SET stream_url = '" + stream + "' WHERE channel = '" + channel + "'"
		c.execute(find_com) 
		conn.commit()
		conn.close()
		
def channelON():
	progress = xbmcgui.DialogProgress()
	progress.create('Progress - Part 2 of 2', 'Updating Channels to Database.')
	from BeautifulSoup import BeautifulStoneSoup
	soup =  BeautifulStoneSoup((open(os.path.join(_addon_path, 'update.xml'), 'r')).read())
	xml_list = soup.findAll("groupy")
	size = len(xml_list)
	i = 0
	for groupy in xml_list:
		channelon = groupy.channelon
		channellogo = groupy.logo
		channelweight = groupy.weight
		updatechannelsON(channelon.text, channellogo.text, channelweight.text)
		percent = min((i*100)/size, 100)
		message = "Message " + str(i) + " out of " + str(size)
		progress.update( percent, "", message, "" )
		if progress.iscanceled():
			break
		i = i + 1
	progress.close()		

def reset_channelsON():
	file = os.path.join(profilePath, 'source.db')
	conn = sqlite3.connect(file)
	c = conn.cursor()
	reset = "UPDATE channels SET visible = '0' WHERE visible = '1'"
	c.execute(reset)
	conn.commit()
	conn.close()

def updatechannelsON(title, logo, weight):
	file = os.path.join(profilePath, 'source.db')
	conn = sqlite3.connect(file)
	c = conn.cursor()
	checkisexsit = "SELECT visible FROM channels WHERE title = '" + title + "'"
	c.execute(checkisexsit)
	answer = c.fetchone()
	if answer is None:
		insert_com = "INSERT into channels VALUES('" + title + "', '" + title + "', '" + logo + "', '', 'xmltv', '1','" + weight + "')"
		c.execute(insert_com) 
		conn.commit()
		conn.close()
	else:
		find_com = "UPDATE channels SET visible = '1' WHERE title = '" + title + "'"
		w_com = "UPDATE channels SET weight = '" + weight + "' WHERE title = '" + title + "'"
		l_com = "UPDATE channels SET logo = '" + logo + "' WHERE title = '" + title + "'"
		c.execute(find_com) 
		c.execute(w_com)
		c.execute(l_com)
		conn.commit()
		conn.close()	

def checklastdate():
	file = os.path.join(_addon_path, 'update.xml')
	from BeautifulSoup import BeautifulStoneSoup
	soup =  BeautifulStoneSoup((open(os.path.join(_addon_path, 'update.xml'), 'r')).read())
	xml_list = soup.findAll("list")
	for group in xml_list:
		date = group.date
		
	return date.text		

dialog = xbmcgui.Dialog()
running=xbmcplugin.getSetting(int(sys.argv[1]), 'running')
DataUrl = getinfo('fourth') 

if running == "false":
	_addon.setSetting('running', 'true')
	CLEARCACHE()
	if dexuser == "":
			xbmcgui.Dialog().ok("Dexter Username", "Your Dexter username is blank")
			inp = dialog.input('Please enter Dexter username', type=xbmcgui.INPUT_ALPHANUM)
			_addon.setSetting('Duser', inp)
			inp = dialog.input('Please enter Dexter password', type=xbmcgui.INPUT_ALPHANUM)
			_addon.setSetting('Dpass', inp)
	else:
					
		if updatevalue == "1":
			ATV()
			updatePJA()
					
		if updatevalue == "0":
			KidsTV()
			UpdateGuide()
			updatePJA()

_addon.setSetting('running', 'false')




	

