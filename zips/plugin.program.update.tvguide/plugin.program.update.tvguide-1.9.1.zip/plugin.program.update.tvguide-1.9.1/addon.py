import pyxbmct.addonwindow as pyxbmct 
import xbmcaddon
import xbmcgui
import urllib, os,re,urllib2
import xbmc
import shutil
import sqlite3
import xbmcplugin
from BeautifulSoup import BeautifulSoup
import datetime
import time
import hashlib


_addon = xbmcaddon.Addon()
_addon_path = _addon.getAddonInfo('path')
month = datetime.datetime.now().strftime("%m")
date = time.strftime("%d%m%y")
_addonr = xbmcaddon.Addon(id = 'script.renegadestv')
profilePath = xbmc.translatePath(_addonr.getAddonInfo('profile'))
dexuser=xbmcplugin.getSetting(int(sys.argv[1]), 'Duser')
dexpword=xbmcplugin.getSetting(int(sys.argv[1]), 'Dpass')
pjaPword=xbmcplugin.getSetting(int(sys.argv[1]), 'passw')
updatevalue=xbmcplugin.getSetting(int(sys.argv[1]), 'Update')
profile = xbmc.translatePath( 'special://profile//')

def DownloaderClass(url,dest):
    dp = xbmcgui.DialogProgress()
    dp.create("Downloading TV Guide","Downloading File")
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
 
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        print percent
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled(): 
        print "DOWNLOAD CANCELLED" 
        del window
	dp.close()

def DownloadedDown():
		
	xbmc.executebuiltin('Notification(Loading, Please Wait. , 20000)')
	
	try:
		Durl = "http://50.7.136.90/stats.php"
		request = urllib2.Request(Durl)
		handle = urllib2.urlopen(request)
		content = handle.read()
		splitted_page = content.split("Streams Experiencing issues</caption>", 1);
		splitted_page = splitted_page[1].split("</tbody></table>", 1)
		soup = BeautifulSoup(splitted_page[0])
		trlist = soup.find("tr")
		result = "[B][COLOR blue]"
	
		for td in soup:
			value = td.findAll("td")
	
	
			for value2 in value:
				rn = value2.text + "   "
				result += rn 
			
		result += "[/COLOR][/B]"
		return result
	except:
		return "Server Down"
	
def Create_main(DownloadedNews, Upd):
	MainWindow = pyxbmct.AddonDialogWindow('Project @lpha TV Guide 1.8.0')
	MainWindow.setGeometry(730, 500, 6, 5)
		
	MainWindow.image = pyxbmct.Image(os.path.join(_addon_path, 'black.jpg'))
        MainWindow.placeControl(MainWindow.image, 0, 0, 6, 5)

	MainWindow.fade_label = pyxbmct.FadeLabel()
        MainWindow.placeControl(MainWindow.fade_label, 0, 1, columnspan=3)
        MainWindow.fade_label.addLabel(DownloadedNews)
		
	Update = pyxbmct.Label(Upd, font='font12', alignment=pyxbmct.ALIGN_CENTER)
	MainWindow.placeControl(Update, 5, 4)
	
	CloseBut = pyxbmct.Button('Close')
	MainWindow.placeControl(CloseBut, 5, 1, columnspan=3)
	FixBut = pyxbmct.Button('Fix Problem')
	MainWindow.placeControl(FixBut, 2, 1, columnspan=3)
	GuideBut = pyxbmct.Button('TV Guides')
	MainWindow.placeControl(GuideBut, 3, 1, columnspan=3)
	SettingsBut = pyxbmct.Button('Settings')
	MainWindow.placeControl(SettingsBut, 1, 1, columnspan=3)
	SettingsBut.controlUp(CloseBut)
	SettingsBut.controlDown(FixBut)
	FixBut.controlUp(SettingsBut)
	FixBut.controlDown(GuideBut)
	GuideBut.controlUp(FixBut)
	GuideBut.controlDown(CloseBut)
	CloseBut.controlUp(GuideBut)
	CloseBut.controlDown(SettingsBut)
	MainWindow.setFocus(CloseBut)
	MainWindow.connect(CloseBut, MainWindow.close)
	MainWindow.connect(GuideBut,lambda: TV_Guides())
	MainWindow.connect(SettingsBut,lambda: SettingsMenu())
	MainWindow.connect(FixBut,lambda: FixMenu())
	MainWindow.connect(pyxbmct.ACTION_NAV_BACK, MainWindow.close)
	MainWindow.doModal()
	del MainWindow

def TV_Guides():
		
	window = pyxbmct.AddonDialogWindow('')
	window.setGeometry(700, 500, 5, 5)
	window.image = pyxbmct.Image(os.path.join(_addon_path, 'black.jpg'))
        window.placeControl(window.image, 0, 0, 5, 5)
	label = pyxbmct.Label('[B][COLOR yellow]Please Select your TV Guide.[/COLOR][/B]', font='font16', alignment=pyxbmct.ALIGN_CENTER)
	label2 = pyxbmct.Label('The Kids TV Guide will only allow childrens channels and will \n alter the skin.  To reset to normal just select TV Guide.', font='font10', alignment=pyxbmct.ALIGN_CENTER)
	window.placeControl(label, 0, 1, columnspan=3)
	window.placeControl(label2, 1, 1, columnspan=3)
	button = pyxbmct.Button('Kids Tv Guide')
	button3 = pyxbmct.Button('TV Guide')
	button4 = pyxbmct.Button('EXIT')
	button5 = pyxbmct.Button('Auto Update \nTV Guide', font='font10')
	button6 = pyxbmct.Button('Auto Update \nKids Guide', font='font10')
	window.placeControl(button, 2, 1, columnspan=3)
	window.placeControl(button3, 3, 1, columnspan=3)
	window.placeControl(button4, 4, 2)
	window.placeControl(button5, 3, 4)
	window.placeControl(button6, 2, 4)
	button4.controlUp(button3)
	button4.controlDown(button)
	button3.controlUp(button)
	button3.controlDown(button4)
	button3.controlRight(button5)
	button.controlUp(button4)
	button.controlDown(button3)
	button.controlRight(button6)
	button5.controlLeft(button3)
	button6.controlLeft(button)
	window.setFocus(button4)
	window.connect(button, lambda: KidsTV())
	window.connect(button3,lambda: ATV())
	window.connect(button5,lambda: autoupdate('1'))
	window.connect(button6,lambda: autoupdate('2'))
	window.connect(button4, window.close)
	window.connect(pyxbmct.ACTION_NAV_BACK, window.close)
	window.doModal()
	UpdateGuide()
	del window

def UpdateGuide():
	
	file = os.path.join(profilePath, 'source.db')
	conn = sqlite3.connect(file)
	c = conn.cursor()
	UserN=xbmcplugin.getSetting(int(sys.argv[1]), 'Duser')
	PWord=xbmcplugin.getSetting(int(sys.argv[1]), 'Dpass')
	UserNameSend = "UPDATE custom_stream_url SET stream_url = REPLACE(stream_url,'projectalpha@myway.com','" + UserN + "')"
	PasswordSend = "UPDATE custom_stream_url SET stream_url = REPLACE(stream_url,'roxanne1','" + PWord + "')"
	c.execute(UserNameSend) 
	c.execute(PasswordSend) 
	conn.commit()
	conn.close()
	xbmc.executebuiltin('Notification(Update, TV Guide Updated.)')
	
def SaveSettings(RetUser, RetPW, RetMonthly):
	_addon.setSetting('Duser', RetUser)
	_addon.setSetting('Dpass', RetPW)
	_addon.setSetting('passw', RetMonthly)
	xbmc.executebuiltin('Notification(Update, Settings Successfully Updated.)')
	
def SettingsMenu():
	
	dexuser=xbmcplugin.getSetting(int(sys.argv[1]), 'Duser')
	dexpword=xbmcplugin.getSetting(int(sys.argv[1]), 'Dpass')
	pjaEmail=xbmcplugin.getSetting(int(sys.argv[1]), 'usern')
	pjaPword=xbmcplugin.getSetting(int(sys.argv[1]), 'passw')
	SettingsWindow = pyxbmct.AddonDialogWindow('')
	SettingsWindow.setGeometry(750, 500, 9, 4)
	SettingsWindow.image = pyxbmct.Image(os.path.join(_addon_path, 'black.jpg'))
        SettingsWindow.placeControl(SettingsWindow.image, 0, 0, 9, 4)
	Title = pyxbmct.Label('[COLOR red][B]Settings[/COLOR][/B]', font='font16', alignment=pyxbmct.ALIGN_CENTER )
	SettingsWindow.placeControl(Title, 0, 1, columnspan=2)
	Title2 = pyxbmct.Label('[COLOR yellow][B]Please enter your details below.[/B][/COLOR]', alignment=pyxbmct.ALIGN_CENTER )
	SettingsWindow.placeControl(Title2, 1, 0, columnspan=4)
	Title3 = pyxbmct.Label('[COLOR blue]Your username is your email you used to register \n and the PJA Password is provided on a monthly subscription[/COLOR]', alignment=pyxbmct.ALIGN_CENTER )
	SettingsWindow.placeControl(Title3, 2, 0, columnspan=4)
	
	DexUser = pyxbmct.Edit('', _alignment=pyxbmct.ALIGN_CENTER)
	SettingsWindow.placeControl(DexUser, 6, 1, columnspan=2)
	DexLabel = pyxbmct.Label('Username:', alignment=pyxbmct.ALIGN_RIGHT)
	SettingsWindow.placeControl(DexLabel, 6, 0)
	DexPW = pyxbmct.Edit('', _alignment=pyxbmct.ALIGN_CENTER, isPassword=True)
	SettingsWindow.placeControl(DexPW, 7, 1, columnspan=2)
	DexPWL = pyxbmct.Label('Password:', alignment=pyxbmct.ALIGN_RIGHT)
	SettingsWindow.placeControl(DexPWL, 7, 0)
	PW = pyxbmct.Edit('',  _alignment=pyxbmct.ALIGN_CENTER, isPassword=True)
	SettingsWindow.placeControl(PW, 5, 1, columnspan=2)
	PWL = pyxbmct.Label('PJA Password:', alignment=pyxbmct.ALIGN_RIGHT)
	SettingsWindow.placeControl(PWL, 5, 0)
	CancelButton = pyxbmct.Button('Save & Close')
	SettingsWindow.placeControl(CancelButton, 8, 2)
	DexUser.setText(dexuser)
	DexPW.setText(dexpword)
	PW.setText(pjaPword)
	CancelButton.controlUp(DexPW)
	DexPW.controlDown(CancelButton)
	DexPW.controlUp(DexUser)
	DexUser.controlDown(DexPW)
	DexUser.controlUp(PW)
	PW.controlDown(DexUser)
	PW.controlUp(CancelButton)
	SettingsWindow.setFocus(CancelButton)
	SettingsWindow.connect(CancelButton, SettingsWindow.close)	
	SettingsWindow.connect(pyxbmct.ACTION_NAV_BACK, SettingsWindow.close)
	SettingsWindow.doModal()
	SaveSettings(DexUser.getText(), DexPW.getText(), PW.getText())
	del SettingsWindow
	xbmcgui.Dialog().ok("Restart", "Please Restart Update TV Guide before continuing!")
def retrieveNews():
		newsUrl = "http://www.pjalpha.co.nf/news.xml"
		request = urllib2.Request(newsUrl)
		handle = urllib2.urlopen(request)

		content = handle.read()

		splitted_page = content.split("<news>", 1);
		splitted_page = splitted_page[1].split("</news>", 1)
		FullRet = "[B][COLOR yellow]News - [/COLOR][COLOR aqua]" +splitted_page[0] +"[/COLOR][/B]"
		return FullRet
def retrieveData(opening, closing, Url):
	try:	
		request = urllib2.Request(Url)
		handle = urllib2.urlopen(request)
		content = handle.read()
		splitted_page = content.split(opening, 1);
		splitted_page = splitted_page[1].split(closing, 1)
		FullRet = splitted_page[0]
		return FullRet
	except:
		return "Unable to retrieve data"
def updDB(Uurl):
	try:
		FullRet = retrieveData('<pja>', '</pja>', Uurl)
		return FullRet
	except:
		xbmcgui.Dialog().ok("Error 2000", "The username %s is not registered \nTo register please visit: \nhttp://pjalpha.byethost14.com/mybb/"%(dexuser))

def KidsTV():
	url ='http://www.pjalpha.co.nf/kids/source.db'
	Set ='http://www.pjalpha.co.nf/kids/settings.xml'
	
	try:
		file = os.path.join(profilePath, 'source.db')
		file2 = os.path.join(profilePath, 'settings.xml')
		DownloaderClass(url, file)
		DownloaderClass(Set, file2)
		updatefiledate()
	except:
		xbmcgui.Dialog().ok("Error", "The server is currently down \n Please try later or visit: \nhttp://pjalpha.byethost14.com/mybb/")
		updatefiledate()
	
def ATV():
	url ='http://www.pjalpha.co.nf/Adult/source.db'
	Set ='http://www.pjalpha.co.nf/Adult/settings.xml'
	try:
		file = os.path.join(profilePath, 'source.db')
		file2 = os.path.join(profilePath, 'settings.xml')
		DownloaderClass(url, file)
		DownloaderClass(Set, file2)
		updatefiledate()
	except:
		xbmcgui.Dialog().ok("Error", "The server is currently down \n Please try later or visit: \nhttp://pjalpha.byethost14.com/mybb/")
		updatefiledate()

def FixMenu():

	FixWindow = pyxbmct.AddonDialogWindow('Fix Menu')
	FixWindow.setGeometry(850, 550, 10, 6)
	FixWindow.image = pyxbmct.Image(os.path.join(_addon_path, 'black.jpg'))
        FixWindow.placeControl(FixWindow.image, 0, 0, 10, 6)
	FixWindow.fade_label = pyxbmct.FadeLabel()
        FixWindow.placeControl(FixWindow.fade_label, 1, 1, columnspan=4)
        FixWindow.fade_label.addLabel(DownloadedDown())
	Title = pyxbmct.Label('[COLOR red]Down Channels[/COLOR]', font='font16', alignment=pyxbmct.ALIGN_CENTER )
	FixWindow.placeControl(Title, 0, 2, columnspan=2)
	Title2 = pyxbmct.Label('[COLOR yellow]Please read the news on previous page first.  Then test the channel before reporting it as broken, try it a few times and \n wait, some channels take time to load!  Type the name of the channel \n not working below and press send.  Only 1 at a time![/COLOR]', font='font10', alignment=pyxbmct.ALIGN_CENTER )
	FixWindow.placeControl(Title2, 2, 0, columnspan=6)
	Title4 = pyxbmct.Label('[COLOR red]Report channel not working:[/COLOR]', alignment=pyxbmct.ALIGN_RIGHT )
	FixWindow.placeControl(Title4, 4, 0, columnspan=2)
	ReportChannel = pyxbmct.Edit('', _alignment=pyxbmct.ALIGN_CENTER)
	FixWindow.placeControl(ReportChannel, 4, 2, columnspan=2)
	ReportButton = pyxbmct.Button('Send')
	FixWindow.placeControl(ReportButton, 4, 4)
	OOpsButton = pyxbmct.Button('(Oops sorry about that!!) Fix')
	FixWindow.placeControl(OOpsButton, 6, 4, rowspan=2, columnspan=2)
	FAQButton = pyxbmct.Button('F.A.Q.')
	FixWindow.placeControl(FAQButton, 6, 0, rowspan=2,  columnspan=2)
	CloseButton = pyxbmct.Button('Close')
	FixWindow.placeControl(CloseButton, 6, 2, rowspan=2, columnspan=2)
	Forum = pyxbmct.Label('[COLOR yellow]The best and easist way to fix a problem \n is to visit the forum[/COLOR]', font='font10', alignment=pyxbmct.ALIGN_CENTER)
	FixWindow.placeControl(Forum, 8, 2, columnspan=2)
	Forum2 = pyxbmct.Label('[COLOR yellow]www.pjalpha.co.nf[/COLOR]', alignment=pyxbmct.ALIGN_CENTER )
	FixWindow.placeControl(Forum2, 9, 2, columnspan=2)
	FAQButton.controlLeft(OOpsButton)
	FAQButton.controlRight(CloseButton)
	OOpsButton.controlLeft(CloseButton)
	OOpsButton.controlRight(FAQButton)
	CloseButton.controlLeft(FAQButton)
	CloseButton.controlRight(OOpsButton)
	CloseButton.controlUp(ReportChannel)
	ReportChannel.controlDown(CloseButton)
	ReportChannel.controlRight(ReportButton)
	ReportButton.controlLeft(ReportChannel)
	FixWindow.setFocus(CloseButton)
	FixWindow.connect(CloseButton, FixWindow.close)
	FixWindow.connect(OOpsButton, lambda: Oops())
	FixWindow.connect(FAQButton, lambda: FAQ())
	FixWindow.connect(ReportButton, lambda: messagesent(ReportChannel.getText()))
	FixWindow.doModal()
	del FixWindow
	
def messagesent(ReportChannel):
	import smtplib
	p = getinfo("first")
	u = getinfo("second")
	server = smtplib.SMTP('smtp.gmail.com', 587)
	server.starttls()
	server.login(u, p)
	msg = date + " - " + dexuser + " - (" + dexpword + ") - Channel Down: " + ReportChannel
	server.sendmail(u, "projectalpha@myway.com", msg)
	server.quit()
	xbmcgui.Dialog().ok("Report Channel Down", ReportChannel, "has been reported as not working!")
	
def Oops():
		response = xbmcgui.Dialog().yesno("Oops, Sorry about that!! FIX", "In the TV Guide have you seen the message: \n \n Oops sorry about that!!! \n It was not possible to load, check settings or try later.")
		if response:
			fixresponse = xbmcgui.Dialog().yesno("Oops, Sorry about that!! FIX", "This error only happens if the TV Guide cannot reach the internet to download the next 24 hours worth of programmes.  It Corrupts a file!! \nPlease press Fix to continue ", yeslabel='Fix', nolabel='Cancel')
			if fixresponse:
				fixoops()
def fixoops():
			
			urlfix = 'http://www.pjalpha.co.nf/Fix/guide.xml'
			file = os.path.join(profilePath, 'guide.xml')
			DownloaderClass(urlfix, file)
			xbmc.executebuiltin('Notification(Fix, Fix Applied, Download TV Guide again and restart Renegades TV Guide., 7000)')
def FAQ():
	
	FAQWindow = pyxbmct.AddonDialogWindow('F.A.Q.')
	FAQWindow.setGeometry(950, 700, 10, 6)
	FAQWindow.image = pyxbmct.Image(os.path.join(_addon_path, 'black.jpg'))
        FAQWindow.placeControl(FAQWindow.image, 0, 0, 10, 6)
	Title = pyxbmct.Label('[COLOR yellow]Does Project Alpha provide the channels/streams?[/COLOR]', alignment=pyxbmct.ALIGN_CENTER )
	FAQWindow.placeControl(Title, 0, 0, columnspan=6)
	TA = pyxbmct.Label('[COLOR orange]Project Alpha does not provide or maintain any of the channels/streams, we only provide the TV Guide database, \n Skins and Update TV Guide with the links to the channels.  The guys who provide the streams work very hard to provide \nthe channels and ask very little in return (we donate regually approx 50% of subscription).[/COLOR]', font='font12', alignment=pyxbmct.ALIGN_CENTER )
	FAQWindow.placeControl(TA, 1, 0, columnspan=6)
	Title2 = pyxbmct.Label('[COLOR yellow]Why do some channels/streams buffer or jump?[/COLOR]', alignment=pyxbmct.ALIGN_CENTER )
	FAQWindow.placeControl(Title2, 2, 0, columnspan=6)
	TA2 = pyxbmct.Label('[COLOR orange]This can be down to serveral things but normally either YOUR internet connection (Are other people using \n it?  / Low connection speed) or the server providing the stream is very busy.  It can also be down to the Fire Stick needing \n a reboot/clearup (Too much on its hard drive).[/COLOR]', font='font12', alignment=pyxbmct.ALIGN_CENTER )
	FAQWindow.placeControl(TA2, 3, 0, columnspan=6)
	Title3 = pyxbmct.Label('[COLOR yellow]Why on some channels am I able to watch one episode / show then it turns off?[/COLOR]', alignment=pyxbmct.ALIGN_CENTER )
	FAQWindow.placeControl(Title3, 4, 0, columnspan=6)
	TA3 = pyxbmct.Label('[COLOR orange]On channels some channels, the server sending the stream needs to ensure you are still there. \n So it resets all the outgoing connections and starts the next episode.  This is to ensure it doesnt get too busy. \n You may find you cannot reconnect as it resets regually (this is normal).[/COLOR]', font='font12', alignment=pyxbmct.ALIGN_CENTER )
	FAQWindow.placeControl(TA3, 5, 0, columnspan=6)
	Title4 = pyxbmct.Label('[COLOR yellow]On Genesis, Why are there no streams available, when I watched it yesterday?[/COLOR]', alignment=pyxbmct.ALIGN_CENTER )
	FAQWindow.placeControl(Title4, 6, 0, columnspan=6)
	TA4 = pyxbmct.Label('[COLOR orange]Sometimes Genesis gives the NO STREAMS AVAILABLE message when the fire stick needs a reboot. \n Unplug the Fire Stick for 20 seconds then plug back in this normally resolves the problem.  Although it maybe \n because Genesis requires an update (Please visit forum to see how to update).[/COLOR]', font='font12', alignment=pyxbmct.ALIGN_CENTER )
	FAQWindow.placeControl(TA4, 7, 0, columnspan=6)
	TA5 = pyxbmct.Label('[COLOR yellow]www.pjalpha.co.nf[/COLOR]', font='font12', alignment=pyxbmct.ALIGN_CENTER )
	FAQWindow.placeControl(TA5, 8, 0, columnspan=6)
	CloseButton = pyxbmct.Button('Close')
	FAQWindow.placeControl(CloseButton, 9, 2, columnspan=2)
	FAQWindow.connect(CloseButton, FAQWindow.close)
	FAQWindow.setFocus(CloseButton)
	FAQWindow.doModal()
	del window
	
def getinfo(input):
	file = os.path.join(_addon_path, 'addon.db')
	conn = sqlite3.connect(file)
	c = conn.cursor()
	query = "SELECT "+ input +" FROM tvguide WHERE username='test@test.com'"
	c.execute(query) 
	answer = c.fetchone()
	
	for rows in answer:
		ret = rows

	conn.close()
	return ret
	

def pProtect(pw):
	ret = hashlib.sha224(pw).hexdigest()
	return ret

def pmon():
	file = os.path.join(_addon_path, 'addon.db')
	conn = sqlite3.connect(file)
	c = conn.cursor()
	query = "SELECT last FROM tvguide WHERE username='test@test.com'"
	c.execute(query) 
	answer = c.fetchone()
	
	for rows in answer:
		ret = rows

	conn.close()
	return ret
	
def checkp():
	dbpass = getinfo("password")
	currpass = pProtect(pjaPword)
	if dbpass == currpass:
		mon = pmon()
		if mon == month:
			return "true"
		else:
			updatePJA()
			return "false"
	else:
		return "false"

def updatefiledate():
	file = os.path.join(_addon_path, 'addon.db')
	conn = sqlite3.connect(file)
	c = conn.cursor()
	c.execute("UPDATE tvguide SET third = " + date + " WHERE username='test@test.com'")
	conn.commit()
	conn.close()
def autoupdate(valuetoret):
	response = xbmcgui.Dialog().yesno("Auto Update", "This will automatically update the TV Guide when you open Update TV Guide. \n Are you sure you wish to proceed?")
	if response:
		_addon.setSetting('Update', valuetoret)
		xbmcgui.Dialog().ok("Auto Update", "To disable Auto Update, please goto add-on settings")
		
def updatePJA():
	file = pProtect(dexuser) + '.pj'
	Uurl = 'http://www.pjalpha.co.nf/data/' + file
	try:
		match = retrieveData('<pjb>', '</pjb>', Uurl)
		if match == month:
			change = updDB(Uurl)
			file = os.path.join(_addon_path, 'addon.db')
			conn = sqlite3.connect(file)
			c = conn.cursor()
			c.execute("UPDATE tvguide SET password = '" + change + "' WHERE username='test@test.com'")
			c.execute("UPDATE tvguide SET last = " + month + " WHERE username='test@test.com'")
			conn.commit()
			conn.close()
			Surl = 'http://www.pjalpha.co.nf/Fix/sources.xml'
			dest = profile + 'sources.xml'
			DownloaderClass(Surl, dest)
			
		else:
			xbmcgui.Dialog().ok("Error 1000", "Please contact PJA on the forum \nhttp://pjalpha.byethost14.com/mybb/")
	except:
		xbmcgui.Dialog().ok("Error 2000", "The username %s is not registered \nTo register please visit: \nhttp://pjalpha.byethost14.com/mybb/"%(dexuser))


	
dialog = xbmcgui.Dialog()
running=xbmcplugin.getSetting(int(sys.argv[1]), 'running')

if running == "false":
	_addon.setSetting('running', 'true')
	
	a = checkp()
	if a == "false":
		xbmcgui.Dialog().ok("Password Check", "Your PJA password is Inncorrect!! \n Please enter the correct password")
		inp = dialog.input('Please enter PJA Password', type=xbmcgui.INPUT_ALPHANUM)
		_addon.setSetting('passw', inp)
	else:
		if dexuser == "":
			xbmcgui.Dialog().ok("Dexter Username", "Your Dexter username is blank")
			inp = dialog.input('Please enter Dexter username', type=xbmcgui.INPUT_ALPHANUM)
			_addon.setSetting('Duser', inp)
		else:
			if dexpword == "":
				xbmcgui.Dialog().ok("Dexter Username", "Your Dexter password is blank")
				inp = dialog.input('Please enter Dexter password', type=xbmcgui.INPUT_ALPHANUM)
				_addon.setSetting('Dpass', inp)
			else:
				if updatevalue == "0":
					DownloadedNewsT = retrieveNews()
					Upd = "Last Updated:[COLOR aqua]" + retrieveData('<updated>','</updated>', 'http://www.pjalpha.co.nf/news.xml') +"[/COLOR]"
					Create_main(DownloadedNewsT, Upd)
				if updatevalue == "1":
					ATV()
					UpdateGuide()
				if updatevalue == "2":
					KidsTV()
					UpdateGuide()

_addon.setSetting('running', 'false')




	

